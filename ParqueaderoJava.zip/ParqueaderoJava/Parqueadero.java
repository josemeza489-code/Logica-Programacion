import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/*
 * Sistema de control de parqueadero para un conjunto residencial.
 * Implementado con programacion estructurada: variables, arreglos,
 * matriz, condicionales, ciclos, funciones y procedimientos.
 * No se crean clases propias ni se aplican principios de POO.
 */
public class Parqueadero {

    // CONSTANTES Y VARIABLES GLOBALES
    static final int MAX_INGRESOS = 40;
    static final int CANTIDAD_COLUMNAS = 3;
    static final int TORRE = 0;
    static final int APARTAMENTO = 1;
    static final int TIPO_VEHICULO = 2;

    static Scanner teclado = new Scanner(System.in);
    static DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    // VECTORES: guardan la placa, las fechas y el estado de cada registro.
    static String[] placas = new String[MAX_INGRESOS];
    static LocalDateTime[] horasIngreso = new LocalDateTime[MAX_INGRESOS];
    static LocalDateTime[] horasSalida = new LocalDateTime[MAX_INGRESOS];
    static boolean[] vehiculoDentro = new boolean[MAX_INGRESOS];

    // MATRIZ: cada fila representa un vehiculo; las columnas guardan torre,
    // apartamento y tipo de vehiculo.
    static String[][] informacion = new String[MAX_INGRESOS][CANTIDAD_COLUMNAS];

    // Cantidad de ingresos registrados durante la ejecucion del programa.
    static int totalIngresos = 0;

    public static void main(String[] args) {
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opcion: ");

            switch (opcion) {
                case 1:
                    registrarIngreso();
                    break;
                case 2:
                    registrarSalida();
                    break;
                case 3:
                    consultarPermanencia();
                    break;
                case 4:
                    mostrarIngresosPorTipo();
                    break;
                case 5:
                    mostrarMayorPermanencia();
                    break;
                case 0:
                    System.out.println("\nPrograma finalizado. Gracias por utilizar el sistema.");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
        } while (opcion != 0);

        teclado.close();
    }

    // PROCEDIMIENTO: muestra las opciones disponibles.
    static void mostrarMenu() {
        System.out.println("\n============================================");
        System.out.println(" SISTEMA DE CONTROL DE PARQUEADERO");
        System.out.println("============================================");
        System.out.println("1. Registrar ingreso de vehiculo");
        System.out.println("2. Registrar salida de vehiculo");
        System.out.println("3. Consultar tiempo de permanencia");
        System.out.println("4. Mostrar ingresos por tipo de vehiculo");
        System.out.println("5. Identificar vehiculo con mayor permanencia");
        System.out.println("0. Salir");
        System.out.println("============================================");
    }

    // PROCEDIMIENTO: registra un nuevo ingreso si hay espacio y la placa no esta dentro.
    static void registrarIngreso() {
        if (totalIngresos >= MAX_INGRESOS) {
            System.out.println("No se pueden registrar mas ingresos. Se alcanzo el limite de 40.");
            return;
        }

        System.out.println("\n--- REGISTRO DE INGRESO ---");
        String placa = leerTexto("Ingrese la placa: ").toUpperCase();

        if (buscarVehiculoDentro(placa) != -1) {
            System.out.println("ERROR: la placa " + placa + " ya se encuentra dentro del parqueadero.");
            System.out.println("Debe registrar la salida antes de permitir un nuevo ingreso.");
            return;
        }

        String torre = leerTexto("Ingrese la torre visitada: ");
        String apartamento = leerTexto("Ingrese el apartamento: ");
        String tipo = leerTipoVehiculo();
        LocalDateTime ingreso = leerFechaHora("Ingrese la fecha y hora de ingreso (dd/MM/aaaa HH:mm): ");

        // Se guardan los datos en el vector y en la matriz.
        placas[totalIngresos] = placa;
        informacion[totalIngresos][TORRE] = torre;
        informacion[totalIngresos][APARTAMENTO] = apartamento;
        informacion[totalIngresos][TIPO_VEHICULO] = tipo;
        horasIngreso[totalIngresos] = ingreso;
        horasSalida[totalIngresos] = null;
        vehiculoDentro[totalIngresos] = true;

        totalIngresos++;

        System.out.println("Ingreso registrado correctamente.");
        System.out.println("Fecha y hora: " + ingreso.format(formatoFecha));
        System.out.println("Registros utilizados: " + totalIngresos + " de " + MAX_INGRESOS);
    }

    // PROCEDIMIENTO: registra la salida de una placa que este dentro.
    static void registrarSalida() {
        System.out.println("\n--- REGISTRO DE SALIDA ---");
        String placa = leerTexto("Ingrese la placa del vehiculo que sale: ").toUpperCase();
        int posicion = buscarVehiculoDentro(placa);

        if (posicion == -1) {
            System.out.println("No se encontro un vehiculo dentro del parqueadero con esa placa.");
            return;
        }

        LocalDateTime salida = leerFechaHora("Ingrese la fecha y hora de salida (dd/MM/aaaa HH:mm): ");

        if (salida.isBefore(horasIngreso[posicion])) {
            System.out.println("ERROR: la salida no puede ser anterior a la fecha y hora de ingreso.");
            return;
        }

        horasSalida[posicion] = salida;
        vehiculoDentro[posicion] = false;
        long minutos = calcularMinutos(posicion, salida);

        System.out.println("Salida registrada correctamente.");
        System.out.println("Tiempo de permanencia: " + formatearDuracion(minutos));
    }

    // PROCEDIMIENTO: consulta el tiempo de permanencia de la ultima entrada de una placa.
    static void consultarPermanencia() {
        System.out.println("\n--- CONSULTA DE PERMANENCIA ---");
        String placa = leerTexto("Ingrese la placa que desea consultar: ").toUpperCase();
        int posicion = buscarUltimoRegistro(placa);

        if (posicion == -1) {
            System.out.println("No hay registros para esa placa.");
            return;
        }

        LocalDateTime fin;
        if (vehiculoDentro[posicion]) {
            fin = LocalDateTime.now();
            System.out.println("El vehiculo todavia se encuentra dentro del parqueadero.");
        } else {
            fin = horasSalida[posicion];
            System.out.println("El vehiculo ya registro su salida.");
            System.out.println("Fecha y hora de salida: " + fin.format(formatoFecha));
        }

        long minutos = calcularMinutos(posicion, fin);
        System.out.println("Placa: " + placas[posicion]);
        System.out.println("Tiempo de permanencia: " + formatearDuracion(minutos));
    }

    // PROCEDIMIENTO: cuenta todos los ingresos registrados por categoria.
    static void mostrarIngresosPorTipo() {
        int carros = 0;
        int motos = 0;
        int bicicletas = 0;

        for (int i = 0; i < totalIngresos; i++) {
            if (informacion[i][TIPO_VEHICULO].equals("Carro")) {
                carros++;
            } else if (informacion[i][TIPO_VEHICULO].equals("Moto")) {
                motos++;
            } else if (informacion[i][TIPO_VEHICULO].equals("Bicicleta")) {
                bicicletas++;
            }
        }

        System.out.println("\n--- CANTIDAD DE INGRESOS POR TIPO ---");
        System.out.println("Carros: " + carros);
        System.out.println("Motos: " + motos);
        System.out.println("Bicicletas: " + bicicletas);
        System.out.println("Total de ingresos: " + totalIngresos);
    }

    // PROCEDIMIENTO: identifica el registro con mayor tiempo de permanencia.
    // Para vehiculos que siguen dentro, cuenta hasta la hora actual.
    static void mostrarMayorPermanencia() {
        if (totalIngresos == 0) {
            System.out.println("Todavia no hay ingresos registrados.");
            return;
        }

        int posicionMayor = 0;
        long mayorTiempo = -1;
        LocalDateTime ahora = LocalDateTime.now();

        for (int i = 0; i < totalIngresos; i++) {
            LocalDateTime fin;
            if (vehiculoDentro[i]) {
                fin = ahora;
            } else {
                fin = horasSalida[i];
            }

            long tiempo = calcularMinutos(i, fin);
            if (tiempo > mayorTiempo) {
                mayorTiempo = tiempo;
                posicionMayor = i;
            }
        }

        System.out.println("\n--- VEHICULO CON MAYOR PERMANENCIA ---");
        System.out.println("Placa: " + placas[posicionMayor]);
        System.out.println("Tipo: " + informacion[posicionMayor][TIPO_VEHICULO]);
        System.out.println("Torre: " + informacion[posicionMayor][TORRE]);
        System.out.println("Apartamento: " + informacion[posicionMayor][APARTAMENTO]);
        System.out.println("Tiempo: " + formatearDuracion(mayorTiempo));
        if (vehiculoDentro[posicionMayor]) {
            System.out.println("Estado: permanece dentro del parqueadero.");
        } else {
            System.out.println("Estado: ya salio del parqueadero.");
        }
    }

    // FUNCION: devuelve la posicion de una placa que actualmente este dentro.
    // Devuelve -1 cuando no existe una coincidencia activa.
    static int buscarVehiculoDentro(String placa) {
        for (int i = 0; i < totalIngresos; i++) {
            if (placas[i].equalsIgnoreCase(placa) && vehiculoDentro[i]) {
                return i;
            }
        }
        return -1;
    }

    // FUNCION: busca desde el registro mas reciente para consultar la ultima visita.
    static int buscarUltimoRegistro(String placa) {
        for (int i = totalIngresos - 1; i >= 0; i--) {
            if (placas[i].equalsIgnoreCase(placa)) {
                return i;
            }
        }
        return -1;
    }

    // FUNCION: calcula la permanencia en minutos entre el ingreso y una fecha final.
    static long calcularMinutos(int posicion, LocalDateTime fin) {
        return Duration.between(horasIngreso[posicion], fin).toMinutes();
    }

    // FUNCION: convierte minutos a horas y minutos para mostrar el resultado.
    static String formatearDuracion(long minutos) {
        long horas = minutos / 60;
        long minutosRestantes = minutos % 60;
        return horas + " hora(s) y " + minutosRestantes + " minuto(s)";
    }

    // FUNCION: solicita y valida el tipo de vehiculo.
    static String leerTipoVehiculo() {
        int opcion;
        do {
            System.out.println("Tipo de vehiculo:");
            System.out.println("1. Carro");
            System.out.println("2. Moto");
            System.out.println("3. Bicicleta");
            opcion = leerEntero("Seleccione el tipo: ");

            if (opcion < 1 || opcion > 3) {
                System.out.println("Opcion no valida. Seleccione 1, 2 o 3.");
            }
        } while (opcion < 1 || opcion > 3);

        if (opcion == 1) {
            return "Carro";
        } else if (opcion == 2) {
            return "Moto";
        } else {
            return "Bicicleta";
        }
    }

    // FUNCION: lee una fecha y hora con el formato solicitado.
    static LocalDateTime leerFechaHora(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim();
            try {
                return LocalDateTime.parse(entrada, formatoFecha);
            } catch (DateTimeParseException e) {
                System.out.println("Formato incorrecto. Ejemplo: 07/11/2026 14:30");
            }
        }
    }

    // FUNCION: lee un numero entero y evita que el programa termine por una entrada incorrecta.
    static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim();
            try {
                return Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un numero entero.");
            }
        }
    }

    // FUNCION: no permite que los campos de texto queden vacios.
    static String leerTexto(String mensaje) {
        String texto;
        do {
            System.out.print(mensaje);
            texto = teclado.nextLine().trim();
            if (texto.isEmpty()) {
                System.out.println("Este dato no puede quedar vacio.");
            }
        } while (texto.isEmpty());
        return texto;
    }
}
