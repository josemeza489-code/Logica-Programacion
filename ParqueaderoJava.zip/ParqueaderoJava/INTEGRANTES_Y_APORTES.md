# Integrantes del grupo y aportes

Completen esta tabla con los nombres reales de los estudiantes antes de publicar el repositorio.

| Integrante | Punto o parte desarrollada | Aporte realizado |
|---|---|---|
| Nombre del estudiante 1 | Analisis del problema y variables | Identifico datos de entrada, procesos y resultados. |
| Nombre del estudiante 2 | Vectores, matriz y registro de ingresos/salidas | Desarrollo el almacenamiento y las validaciones de placas. |
| Nombre del estudiante 3 | Funciones, procedimientos y consultas | Desarrollo los calculos de permanencia y los reportes. |
| Nombre del estudiante 4 | Pruebas de escritorio y revision | Verifico los casos de prueba y reviso el funcionamiento. |

Si el grupo tiene menos integrantes, eliminen las filas que no necesiten. Si tiene mas, agreguen filas y describan el aporte real de cada persona. No dejen nombres de ejemplo en la entrega final.
