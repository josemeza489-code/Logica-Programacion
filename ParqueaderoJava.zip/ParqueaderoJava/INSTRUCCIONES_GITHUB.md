# Publicar el trabajo en GitHub

El repositorio debe quedar publico, como solicita la guia. Para publicarlo:

1. Entren a https://github.com/new e inicien sesion.
2. En **Repository name**, escriban `sistema-control-parqueadero`.
3. Seleccionen **Public** y creen el repositorio.
4. Descompriman `ParqueaderoJava.zip` en su computador.
5. En la pagina del repositorio, seleccionen **Add file** y luego **Upload files**.
6. Arrastren los archivos de la carpeta `ParqueaderoJava` (incluidos `Parqueadero.java`, `README.md`, `pruebas_escritorio.txt`, `INTEGRANTES_Y_APORTES.md` e `INSTRUCCIONES_GITHUB.md`). No suban archivos `.class`.
7. Escriban un mensaje como `Entrega del sistema de parqueadero` y presionen **Commit changes**.
8. Copien la direccion del repositorio publico y péguenla en el espacio de entrega de la actividad.

Antes de entregar, completen `INTEGRANTES_Y_APORTES.md` con los nombres y aportes reales del grupo.
