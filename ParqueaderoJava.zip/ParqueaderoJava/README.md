# Sistema de control de parqueadero para conjunto residencial

## 1. Descripcion del problema

Un conjunto residencial necesita llevar el control de los vehiculos visitantes. El sistema permite registrar hasta 40 ingresos durante la ejecucion, guardar la placa, torre, apartamento, tipo de vehiculo y fecha y hora de ingreso. Tambien permite registrar la salida, consultar el tiempo de permanencia, contar los ingresos por tipo e identificar el vehiculo que lleva mas tiempo en el parqueadero.

Una misma placa no puede tener dos ingresos activos al mismo tiempo. Para permitir un nuevo ingreso de esa placa, primero debe registrarse su salida.

## 2. Objetivo

Crear un programa en Java que organice la informacion de los visitantes de manera sencilla, controle las entradas y salidas y entregue consultas sobre el uso del parqueadero.

## 3. Analisis del problema

### Datos de entrada
- Placa del vehiculo.
- Torre que visita.
- Numero de apartamento.
- Tipo de vehiculo: carro, moto o bicicleta.
- Fecha y hora de ingreso.
- Placa y fecha/hora de salida para registrar una salida.

### Procesos
1. Mostrar el menu principal.
2. Revisar que no se hayan registrado ya 40 ingresos.
3. Buscar si la placa ya se encuentra dentro del parqueadero.
4. Guardar los datos del nuevo ingreso.
5. Buscar la placa para registrar su salida y validar que la salida no sea anterior al ingreso.
6. Calcular la diferencia entre la fecha/hora de entrada y la fecha/hora final.
7. Contar los ingresos de carros, motos y bicicletas.
8. Comparar los tiempos de permanencia para encontrar el mayor.

### Datos de salida
- Mensaje de ingreso o salida registrada.
- Tiempo de permanencia en horas y minutos.
- Cantidad de ingresos por cada tipo de vehiculo.
- Datos del vehiculo con mayor permanencia.
- Mensajes de error cuando los datos no cumplen las condiciones.

## 4. Variables, vectores y matriz

| Elemento | Tipo | Uso |
|---|---|---|
| `totalIngresos` | `int` | Cuenta los ingresos registrados. |
| `opcion` | `int` | Guarda la opcion elegida en el menu. |
| `placas` | Vector `String[40]` | Guarda las placas. |
| `horasIngreso` | Vector `LocalDateTime[40]` | Guarda fecha y hora de cada ingreso. |
| `horasSalida` | Vector `LocalDateTime[40]` | Guarda fecha y hora de salida. |
| `vehiculoDentro` | Vector `boolean[40]` | Indica si el vehiculo sigue dentro. |
| `informacion` | Matriz `String[40][3]` | Guarda torre, apartamento y tipo de vehiculo. |

Cada fila de la matriz corresponde al mismo registro que ocupa esa posicion en los vectores.

## 5. Condicionales

Se utilizan `if`, `else if`, `else` y `switch` para:
- Comprobar si se alcanzo el limite de 40 ingresos.
- Evitar que una placa ingrese dos veces sin registrar salida.
- Validar el tipo de vehiculo.
- Verificar que la fecha/hora de salida no sea anterior al ingreso.
- Elegir la opcion del menu y mostrar el resultado correspondiente.

## 6. Ciclos

Se utilizan ciclos `do-while` y `for`:
- `do-while`: mantiene activo el menu hasta que el usuario seleccione salir.
- `while`: vuelve a pedir datos cuando el formato o el contenido no son validos.
- `for`: recorre los registros para buscar placas, contar tipos y comparar permanencias.

## 7. Funciones y procedimientos

En Java todos se escriben como metodos. Para este trabajo se separan asi:

### Procedimientos (no devuelven un resultado: `void`)
- `mostrarMenu()`: presenta las opciones.
- `registrarIngreso()`: guarda un ingreso valido.
- `registrarSalida()`: registra la salida de un vehiculo.
- `consultarPermanencia()`: muestra cuanto tiempo lleva o estuvo un vehiculo.
- `mostrarIngresosPorTipo()`: muestra los conteos por categoria.
- `mostrarMayorPermanencia()`: identifica el registro con mayor permanencia.

### Funciones (devuelven un resultado)
- `buscarVehiculoDentro()`: devuelve la posicion de una placa que sigue dentro o `-1`.
- `buscarUltimoRegistro()`: devuelve la posicion de la visita mas reciente o `-1`.
- `calcularMinutos()`: devuelve la permanencia en minutos.
- `formatearDuracion()`: devuelve el tiempo en horas y minutos.
- `leerTipoVehiculo()`: devuelve el tipo seleccionado.
- `leerFechaHora()`: devuelve una fecha y hora valida.
- `leerEntero()`: devuelve un numero entero valido.
- `leerTexto()`: devuelve un texto que no este vacio.

## 8. Procedimiento general (algoritmo)

1. Iniciar los vectores y la matriz con capacidad para 40 registros.
2. Mostrar el menu.
3. Leer la opcion seleccionada.
4. Ejecutar el procedimiento correspondiente.
5. Si se registra un ingreso, validar capacidad y placa; si todo esta correcto, guardar la informacion.
6. Si se registra una salida, buscar una placa activa, validar la fecha y guardar la salida.
7. Para las consultas, recorrer los registros y calcular los resultados.
8. Volver al menu hasta que se seleccione la opcion 0.
9. Finalizar el programa.

## 9. Pruebas de escritorio

Las siguientes pruebas usan fechas de ejemplo. Se deben introducir en el formato `dd/MM/aaaa HH:mm`.

| Prueba | Datos / accion | Resultado esperado |
|---|---|---|
| 1. Ingreso correcto | Placa ABC123, torre 2, apartamento 301, carro, ingreso 07/11/2026 08:00 | El sistema confirma el ingreso y muestra 1 de 40 registros. |
| 2. Placa repetida | Intentar ingresar ABC123 otra vez sin registrar su salida | El sistema rechaza el ingreso e indica que primero debe registrarse la salida. |
| 3. Salida correcta | Placa ABC123, salida 07/11/2026 10:30 | La salida se registra y la permanencia es 2 horas y 30 minutos. |
| 4. Nuevo ingreso despues de salir | Registrar ABC123 nuevamente despues de la salida anterior | El sistema permite el nuevo ingreso, si no se han completado los 40 registros. |
| 5. Salida anterior al ingreso | Ingreso 07/11/2026 08:00 y salida 07/11/2026 07:30 | El sistema rechaza la salida porque la fecha/hora es anterior. |
| 6. Conteo por tipo | Registrar 2 carros, 1 moto y 1 bicicleta | El reporte muestra carros: 2, motos: 1, bicicletas: 1 y total: 4. |
| 7. Capacidad maxima | Intentar registrar un ingreso cuando ya existen 40 registros | El sistema no permite el ingreso numero 41. |
| 8. Consulta de placa inexistente | Consultar la placa XYZ999, que no esta registrada | El sistema informa que no hay registros para esa placa. |

## 10. Como ejecutar el programa

1. Instalar el JDK de Java.
2. Abrir una terminal en la carpeta donde esta `Parqueadero.java`.
3. Compilar con:

   ```bash
   javac Parqueadero.java
   ```

4. Ejecutar con:

   ```bash
   java Parqueadero
   ```

## 11. Consideraciones

- El limite de 40 corresponde a 40 registros de ingreso durante una ejecucion del programa. Si se cierra, la informacion en memoria se pierde, porque el enunciado no solicita guardar datos en archivos o bases de datos.
- La fecha y hora se ingresan manualmente para que el usuario pueda registrar el momento correspondiente y para facilitar las pruebas.
- Si un vehiculo sigue dentro, las consultas calculan su permanencia hasta la fecha y hora actual del computador.
- El codigo usa una sola clase como estructura obligatoria de Java, pero no crea objetos propios ni aplica encapsulamiento, herencia o polimorfismo.
